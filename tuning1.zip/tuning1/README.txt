
Trial 50 Complete [00h 00m 13s]
val_accuracy: 0.5166666507720947

Best val_accuracy So Far: 0.75
Total elapsed time: 00h 09m 25s
Best Activation Function: elu
Best Optimizer: adam
Best Learning Rate: 0.01
Best Dropout Rate: 0.0




import keras_tuner as kt
from tensorflow import keras

def build_model(hp):
    
    model = keras.Sequential()
    
    # we define the activation and dropout hyperparameters to tune
    hp_activation = hp.Choice('activation', values=['relu', 'sigmoid', 'elu'])
    hp_dropout_rate = hp.Choice('dropout_rate', values=[0.0, 0.1, 0.2])
    
    # we build the architecture (3 layers, 20 neurons each)
    model.add(keras.layers.Dense(20, activation=hp_activation, input_shape=(L,)))
    model.add(keras.layers.Dropout(rate=hp_dropout_rate))

    model.add(keras.layers.Dense(20, activation=hp_activation))
    model.add(keras.layers.Dropout(rate=hp_dropout_rate))

    model.add(keras.layers.Dense(20, activation=hp_activation))
    model.add(keras.layers.Dropout(rate=hp_dropout_rate))

    model.add(keras.layers.Dense(1, activation='sigmoid'))
    
    # we set the optimizer and learning rate hyperparameters to tune
    hp_learning_rate = hp.Choice('learning_rate', values=[1e-1, 1e-2, 1e-3, 1e-4, 1e-5, 1e-6])
    hp_optimizer = hp.Choice('optimizer', values=['adam', 'rmsprop', 'sgd'])
    
    if hp_optimizer == 'adam':
        optimizer = keras.optimizers.Adam(learning_rate=hp_learning_rate)
    elif hp_optimizer == 'rmsprop':
        optimizer = keras.optimizers.RMSprop(learning_rate=hp_learning_rate)
    else:
        optimizer = keras.optimizers.SGD(learning_rate=hp_learning_rate, nesterov=True)

    model.compile(
        optimizer=optimizer,
        loss='binary_crossentropy',
        metrics=['accuracy']
    )
    
    return model

# 1. Initialize the RandomSearch tuner
tuner = kt.RandomSearch(
    hypermodel=build_model,
    objective='val_accuracy',
    max_trials=50,  # The maximum number of random combinations to test
    executions_per_trial=1, # Number of models to train per trial (increase to reduce variance)
    directory='tuning1',
    project_name='random_search_demo'
)

# 2. View a summary of the search space
tuner.search_space_summary()

# 3. Execute the search (assuming you have x_train, y_train, x_val, y_val)
tuner.search(
    x_train, 
    y_train, 
    epochs=20, 
    validation_data=(x_val, y_val)
)